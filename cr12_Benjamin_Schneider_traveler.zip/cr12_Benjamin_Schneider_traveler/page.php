<?php get_header(); ?>
	<div class="container-fluid">
		<div class="blog-header">
			<h1 class="blog-title"><?php bloginfo('name'); ?></h1>
			<p class="lead blog-description"><?php bloginfo('description'); ?></p>
		</div>
		<hr>
		<div class="container">
			<div class="pageheader">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<h1><?php the_title(); ?></h1>
			</div>
			<br>
			<div class="entry">
				<?php the_content(); ?>
			</div>
			<?php endwhile; endif; ?>
		</div> <!-- end of container -->
	</div> <!-- end of container-fluid --> 
<?php get_footer(); ?>