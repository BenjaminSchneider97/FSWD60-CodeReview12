<footer class="blog-footer">
	<div class="footer-content">
		<p>&copy; <?php echo Date('Y'); ?><?php echo " - " ?> <?php bloginfo('name'); ?></p>
	</div>
</footer>
   <?php wp_footer(); ?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
	</body>
</html>