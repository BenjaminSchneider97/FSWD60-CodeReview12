<?php get_header(); ?>
	<div class="container-fluid">
		<div class="blog-header">
			<h1 class="blog-title"><?php bloginfo('name'); ?></h1>
			<p class="lead blog-description"><?php bloginfo('description'); ?></p>
		</div>
		<hr>
		<div class="container">
			<div class="goback" onclick="history.back();">
				<i class="fas fa-arrow-left"></i><button class="gobackbutton" type="button">Go back</button>
			</div>
			<div class="row">
				<?php if(have_posts()) :  ?>
				<?php while(have_posts()) : the_post(); ?>
				<div class="col-sm-8">
					<div class="blog-post">
						<div class="blog-post-thumbnail">
							<?php if(has_post_thumbnail()) : ?>
							<?php the_post_thumbnail(); ?>
							<?php endif; ?>
						</div>
						<div class="blog-post-title">
							<h2><?php the_title(); ?></h2>
						</div>
						<div class="blog-post-date-author">
							<?php the_time('F j, Y - g:i a'); ?>
							| author: <?php the_author(); ?>
						</div>
						<br>
						<div class="blog-post-content">
							<?php the_content(); ?>
						</div>
						<hr>
						<div class="blog-post-comment">
							<?php comments_template(); ?>
						</div>
					</div><!-- End of blog-post-->
				</div><!-- End of col -->
				<?php endwhile; ?>
				<?php else : ?>
				<p><?php__('Sorry no posts found!'); ?></p>
				<?php endif; ?>	
				<div class="col-sm-4">
					<div class="sidebar-module-inset">
						<?php
							if(is_active_sidebar('sidebar')):
							dynamic_sidebar('sidebar');
							endif;  
						?>
					</div><!-- End of sidebar-modile-inset -->
				</div><!-- End of col -->
			</div><!-- End of row -->
		</div><!-- End of container -->
	</div><!-- End of container-fluid -->
<?php get_footer(); ?>